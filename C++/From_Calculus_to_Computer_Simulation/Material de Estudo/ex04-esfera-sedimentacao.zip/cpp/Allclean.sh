rm *.pdf
rm *.out
rm *.dat
