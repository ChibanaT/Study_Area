gfortran main.f90
./a.out
